import pprint

from botr.api import API

pp = pprint.PrettyPrinter()

# Please update kkkk with your key and ssss with your secret
api = API('kkkkkkkk', 'ssssssssssssssssssssssss')

response = api.call('/videos/list')
pp.pprint(response)

# and update zzzz with a video_key listed by the call above
# response = api.call('/videos/show', {'video_key': 'zzzzzzzz'})
# pp.pprint(response)

